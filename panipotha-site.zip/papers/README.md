Put your PDF files in this folder.

Each PDF's filename must match the "file" field you set for it in ../papers.json
(e.g. papers/ol-maths-2024-p1.pdf).
