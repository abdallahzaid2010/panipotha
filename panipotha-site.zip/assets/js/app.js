/* ============================================================
   app.js — renders the paper index, search/filter, preview,
   share-link and the sign-in gate on downloads.
   ============================================================ */

let PAPERS = [];
let currentUser = null;

const els = {
  list: document.getElementById("paperList"),
  count: document.getElementById("filterCount"),
  search: document.getElementById("searchInput"),
  level: document.getElementById("levelFilter"),
  subject: document.getElementById("subjectFilter"),
  userChip: document.getElementById("userChip"),
  previewBackdrop: document.getElementById("previewModal"),
  previewFrame: document.getElementById("previewFrame"),
  previewTitle: document.getElementById("previewTitle"),
  previewDownload: document.getElementById("previewDownload"),
  gateBackdrop: document.getElementById("gateModal"),
  toast: document.getElementById("toast"),
};

init();

async function init() {
  try {
    const res = await fetch("papers.json", { cache: "no-store" });
    PAPERS = await res.json();
  } catch (e) {
    PAPERS = [];
  }
  populateFilters();
  render();

  els.search.addEventListener("input", render);
  els.level.addEventListener("change", render);
  els.subject.addEventListener("change", render);

  document.querySelectorAll("[data-close-modal]").forEach(btn => {
    btn.addEventListener("click", closeModals);
  });
  [els.previewBackdrop, els.gateBackdrop].forEach(backdrop => {
    backdrop?.addEventListener("click", e => { if (e.target === backdrop) closeModals(); });
  });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeModals(); });

  const gateSignIn = document.getElementById("gateSignIn");
  if (gateSignIn) gateSignIn.href = "login.html?next=" + encodeURIComponent(location.pathname);

  // Auth state (from auth.js, loaded as a module on this page)
  if (window.PanipothaAuth) {
    window.PanipothaAuth.watchAuth(user => {
      currentUser = user;
      renderUserChip();
    });
  } else {
    renderUserChip();
  }
}

function populateFilters() {
  const levels = [...new Set(PAPERS.map(p => p.level))].sort();
  const subjects = [...new Set(PAPERS.map(p => p.subject))].sort();
  for (const l of levels) els.level.add(new Option(l, l));
  for (const s of subjects) els.subject.add(new Option(s, s));
}

function render() {
  const q = els.search.value.trim().toLowerCase();
  const level = els.level.value;
  const subject = els.subject.value;

  const filtered = PAPERS.filter(p => {
    if (level && p.level !== level) return false;
    if (subject && p.subject !== subject) return false;
    if (q && !(`${p.title} ${p.subject} ${p.year}`.toLowerCase().includes(q))) return false;
    return true;
  });

  els.count.textContent = `${filtered.length} of ${PAPERS.length} papers`;

  if (!filtered.length) {
    els.list.innerHTML = `<div class="empty-state">No papers match your search. Try clearing a filter.</div>`;
    return;
  }

  els.list.innerHTML = filtered.map((p, i) => `
    <div class="paper-row">
      <div class="paper-num">${String(i + 1).padStart(2, "0")}</div>
      <div class="paper-main">
        <div class="paper-title">${escapeHtml(p.title)}</div>
        <div class="paper-meta">
          <span class="tag">${escapeHtml(p.level)}</span>
          <span class="tag">${escapeHtml(p.subject)}</span>
          <span class="tag medium">${escapeHtml(p.medium)} medium</span>
          <span class="tag">${p.year}</span>
          <span class="tag">${escapeHtml(p.type)}</span>
          <span class="tag">${escapeHtml(p.size || "")}</span>
        </div>
      </div>
      <div class="paper-actions">
        <button class="icon-btn" data-preview="${p.id}">Preview</button>
        <button class="icon-btn" data-share="${p.id}">Share</button>
        <button class="icon-btn locked" data-download="${p.id}">Download</button>
      </div>
    </div>
  `).join("");

  els.list.querySelectorAll("[data-preview]").forEach(b =>
    b.addEventListener("click", () => openPreview(b.dataset.preview)));
  els.list.querySelectorAll("[data-share]").forEach(b =>
    b.addEventListener("click", () => shareLink(b.dataset.share)));
  els.list.querySelectorAll("[data-download]").forEach(b =>
    b.addEventListener("click", () => requestDownload(b.dataset.download)));
}

function findPaper(id) {
  return PAPERS.find(p => p.id === id);
}

function openPreview(id) {
  const p = findPaper(id);
  if (!p) return;
  els.previewTitle.textContent = p.title;
  els.previewFrame.src = p.file;
  els.previewDownload.onclick = () => requestDownload(id);
  els.previewBackdrop.classList.add("open");
}

function shareLink(id) {
  const url = `${location.origin}${location.pathname.replace(/index\.html$/, "")}?paper=${id}`;
  navigator.clipboard?.writeText(url).then(() => showToast("Link copied to clipboard"))
    .catch(() => showToast(url));
}

function requestDownload(id) {
  const p = findPaper(id);
  if (!p) return;
  if (window.PanipothaAuth && window.PanipothaAuth.isConfigured() && !currentUser) {
    els.gateBackdrop.dataset.pendingId = id;
    els.gateBackdrop.classList.add("open");
    return;
  }
  triggerDownload(p);
}

function triggerDownload(p) {
  const a = document.createElement("a");
  a.href = p.file;
  a.download = p.file.split("/").pop();
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function closeModals() {
  els.previewBackdrop?.classList.remove("open");
  els.gateBackdrop?.classList.remove("open");
  if (els.previewFrame) els.previewFrame.src = "";
}

function renderUserChip() {
  if (!els.userChip) return;
  if (currentUser) {
    els.userChip.innerHTML = `<span class="user-chip">Signed in as <strong>${escapeHtml(currentUser.email || "user")}</strong></span>
      <button class="btn btn-ghost" id="signOutBtn">Sign out</button>`;
    document.getElementById("signOutBtn").addEventListener("click", async () => {
      await window.PanipothaAuth.logOut();
    });
  } else {
    els.userChip.innerHTML = `<a class="btn btn-ghost" href="login.html">Sign in</a>`;
  }
}

function showToast(msg) {
  if (!els.toast) return;
  els.toast.textContent = msg;
  els.toast.classList.add("show");
  setTimeout(() => els.toast.classList.remove("show"), 2200);
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}
