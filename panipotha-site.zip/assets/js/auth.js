/* ============================================================
   auth.js — Firebase Authentication for a static (GitHub Pages) site.
   Fill in FIREBASE_CONFIG below with your own project's config
   (Firebase console → Project settings → General → Your apps).
   This file is safe to be public: Firebase web config is not a
   secret, access is controlled by Firebase's own security rules.
   ============================================================ */

const FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  appId: "YOUR_APP_ID"
};

// Loaded via <script type="module"> — see index.html / login.html
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

let auth = null;
let configured = FIREBASE_CONFIG.apiKey !== "YOUR_API_KEY";

if (configured) {
  const app = initializeApp(FIREBASE_CONFIG);
  auth = getAuth(app);
}

// Broadcasts the current user (or null) to any page listening.
function watchAuth(callback) {
  if (!configured) {
    // No Firebase project connected yet — treat everyone as signed out
    // and log a hint for the site owner instead of breaking the page.
    console.warn("Panipotha: Firebase is not configured yet — sign-in is disabled. See assets/js/auth.js");
    callback(null);
    return;
  }
  onAuthStateChanged(auth, callback);
}

async function emailSignIn(email, password) {
  return signInWithEmailAndPassword(auth, email, password);
}

async function emailSignUp(email, password) {
  return createUserWithEmailAndPassword(auth, email, password);
}

async function googleSignIn() {
  return signInWithPopup(auth, new GoogleAuthProvider());
}

async function logOut() {
  return signOut(auth);
}

window.PanipothaAuth = {
  watchAuth,
  emailSignIn,
  emailSignUp,
  googleSignIn,
  logOut,
  isConfigured: () => configured
};
